# 01_spam_recognition.py
# 垃圾邮件识别案例
# 数据集：10001个正常邮件和垃圾邮件样本
# 特征表示：TF-IDF作为文本特征表示
# 模型：NB, SVM
import numpy as np
import re
import string
import sklearn.model_selection as ms
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn import metrics

import jieba
from sklearn.feature_extraction.text import TfidfVectorizer

label_name_map = ["垃圾邮件", "正常邮件"]


# 分词
def tokenize_text(text):
    tokens = jieba.cut(text)  # 分词
    tokens = [t.strip() for t in tokens]
    return tokens


# 过滤标点符号
def remove_special_char(text):
    tokens = tokenize_text(text)  # 调用函数做分词
    # escape: 对需要转义的字符做转义处理
    pattern = re.compile(  # 编译正则表达式
        "[{}]".format(re.escape(string.punctuation)))
    # sub: 进行正则匹配字符串替换
    # filter: 过滤掉不符合条件的元素，返回符合条件的元素构成的列表
    filtered_tokens = filter(
        None, [pattern.sub("", token) for token in tokens])
    filtered_text = " ".join(filtered_tokens)

    return filtered_text


# 过滤停用词
def remove_stopwords(text):
    tokens = tokenize_text(text)  # 分词
    filtered_tokens = [t for t in tokens
                       if t not in stopword_list]
    filtered_text = " ".join(filtered_tokens)
    return filtered_text


# 规范化处理
def normalize_corpus(corpus):
    result = []  # 处理后的结果
    for text in corpus:
        text = remove_special_char(text)  # 过滤符号
        text = remove_stopwords(text)  # 过滤停用词
        result.append(text)
    return result


# 计算TF-IDF
def tfidf_extractor(corpus):
    vectorizer = TfidfVectorizer(min_df=1,  # 设置最小词频
                                 norm="l2",
                                 smooth_idf=True,  # 平滑处理
                                 use_idf=True)  # 是否使用IDF指标
    features = vectorizer.fit_transform(corpus)
    return vectorizer, features  # 返回对象、特征值


# 读取语料, 返回邮件内容、类别
def get_data():
    corpus = []  # 邮件内容
    labels = []  # 邮件类别

    # 正常邮件
    with open("ham_data.txt", encoding="utf-8") as f:
        for line in f.readlines():
            corpus.append(line)  # 邮件内容
            labels.append(1)  # 类别编号

    # 垃圾邮件
    with open("spam_data.txt", encoding="utf-8") as f:
        for line in f.readlines():
            corpus.append(line)  # 邮件内容
            labels.append(0)  # 类别编号

    return corpus, labels


# 过滤空文档
def remove_empty_docs(corpus, labels):
    filtered_corpus = []  # 过滤后的邮件
    filtered_labels = []  # 过滤后的标签

    for doc, label in zip(corpus, labels):
        if doc.strip():  # 去空格后不是空字符串
            filtered_corpus.append(doc)
            filtered_labels.append(label)

    return filtered_corpus, filtered_labels


# 打印分类指标
def print_metrics(labels, pred):
    # Accuracy
    acc = metrics.accuracy_score(labels, pred)
    # Precision
    prec = metrics.precision_score(labels,
                                   pred,
                                   average="weighted")
    # Recall
    recall = metrics.recall_score(labels,
                                  pred,
                                  average="weighted")
    # F1
    f1 = metrics.f1_score(labels,
                          pred,
                          average="weighted")

    print("正确率:%.2f, 查准率:%.2f, 召回率:%.2f, F1:%.2f"
          % (acc, prec, recall, f1))


if __name__ == "__main__":
    global stopword_list
    with open("stop_words.utf8", encoding="utf-8") as f:
        stopword_list = f.readlines()

    # 读取语料库
    corpus, labels = get_data()
    corpus, labels = remove_empty_docs(corpus, labels)
    print("样本数量:", len(labels))

    # 打印前N个样本
    # for i in range(5):
    #     print("类别:", labels[i], " 内容:", corpus[i])

    # 划分训练集、测试集
    train_x, test_x, train_y, test_y = ms.train_test_split(
        corpus, labels,  # 输入、标签
        test_size=0.1,  # 测试集比例
        random_state=36)  # 随机种子(产生随机序列初始值)

    # 规范化处理(过滤符号、过滤停用词)
    norm_train_x = normalize_corpus(train_x)
    norm_test_x = normalize_corpus(test_x)
    print("规范化处理结束.")

    # 计算TF-IDF(文本的特征)
    tfidf_vec, train_features = tfidf_extractor(norm_train_x)
    test_features = tfidf_vec.transform(norm_test_x)
    print("计算TF-IDF特征结束.")

    print("朴素贝叶斯模型:")
    nb = MultinomialNB()  # 多分类朴素贝叶斯
    nb.fit(train_features, train_y)  # 训练
    nb_pred = nb.predict(test_features)  # 测试集预测
    print_metrics(test_y, nb_pred)  # 打印分类指标

    print("")

    print("支持向量机模型:")
    svm = SGDClassifier()
    svm.fit(train_features, train_y)# 训练
    svm_pred = svm.predict(test_features)# 测试集预测
    print_metrics(test_y, svm_pred)# 打印分类指标
