# movielens数据集说明

## 变量说明

### 用户数据 users.dat

1. UserID	用户ID
2. Gender	性别
3. Age	年龄
4. Occupation	职业
5. Zip-code		地区邮政编码

### 电影数据  movies.dat

1. MovieID		电影ID
2. Title		标题
3. Genres		类型

### 评分数据  ratings.dat

1. UserID		用户ID
2. MovieID		电影ID
3. Rating		评分
4. Timestamp	时间