python setup.py install
mv build/*/*.so ./
rm -rf build/