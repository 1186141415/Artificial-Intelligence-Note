# 03_word_tag.py
# 利用jieba库实现词性标注
import jieba.posseg as psg

def pos(text):
    results = psg.cut(text) # 分词、词性标注
    for w, t in results:
        print("%s/%s" % (w, t), end=" ")
    print("")

text = "梅兰芳大剧院星期六晚上有演出"
pos(text)

text = "呼伦贝尔大草原"
pos(text)