# -*- coding: utf-8 -*-
# 04_get_kw_demo.py
# 利用TF-IDF、TextRank算法提取文章关键词
import math
import jieba
import jieba.posseg as psg
from gensim import corpora, models
from jieba import analyse
import functools
import numpy as np

# 读取停用词
def get_stopword_list():
    path = "stopword.txt" # 停用词文件路径
    with open(path, "r", encoding="utf8") as f:
        lines = f.readlines()
    stop_words = [w.replace("\n", "") for w in lines]
    return stop_words

# 过滤停用词
def word_filter(seg_list):
    filter_list = [] # 过滤后的词列表
    for w in seg_list:
        if not w in stopword_list and len(w) > 1:
            filter_list.append(w)
    return filter_list

def load_data(corpus_path): # 读取语料库文件中的内容
    doc_list = [] # 文档内容
    with open(corpus_path, "r", encoding="utf8") as f:
        for line in f.readlines():
            content = line.strip() # 去空格
            seg_list = jieba.cut(content) # 分词
            filter_list = word_filter(seg_list) # 去除停用词
            doc_list.append(filter_list)
    return doc_list

def train_idf(doc_list): # 计算每个词的IDF值
    idf_dic = {} # key:词   value:idf值
    tt_count = len(doc_list) # 总文档数量

    # 统计每个词出现的文档数量
    for doc in doc_list:
        doc_set = set(doc) # 对每个文档词语去重
        for word in doc_set:
            if word in idf_dic.keys(): # 在字典中
                num = idf_dic[word]
                num += 1
                idf_dic[word] = num
            else:
                idf_dic[word] = 1

    for word, doc_cnt in idf_dic.items():
        # 计算IDF值，并覆盖字典中的文档数量
        idf_dic[word] = math.log(tt_count / (doc_cnt + 1))

    # 没有出现在语料库中的词，计算默认IDF
    default_idf = math.log(tt_count / 1.0)

    return idf_dic, default_idf


class TfIdf():
    def __init__(self, idf_dic, default_idf, word_list,
                 kw_num):
        """
        构造方法
        :param idf_dic: IDF值字典
        :param default_idf: 默认IDF值
        :param word_list: 待计算文本
        :param kw_num: 关键词数量
        """
        self.word_list = word_list
        self.idf_dic = idf_dic
        self.default_idf = default_idf
        self.kw_num = kw_num
        self.tf_dic = self.get_tf_dic() # 词频

    def get_tf_dic(self): # 计算词频
        tf_dict = {} # key:词 value:词频
        for word in self.word_list: # 遍历每个词
            if word in tf_dict.keys():
                num = tf_dict[word]
                num += 1
                tf_dict[word] = num
            else:
                tf_dict[word] = 1

        total = len(self.word_list) # 词语个数
        for word, word_cnt in tf_dict.items():
            # 计算词频
            tf_dict[word] = float(word_cnt) / float(total)
        return tf_dict

    def get_tfidf(self): # 计算TF-IDF值
        tfidf_dict = {}
        for word in self.word_list:
            idf = self.idf_dic.get(word, self.default_idf)
            tf = self.tf_dic.get(word, 0)
            tfidf = tf * idf # tf-idf
            tfidf_dict[word] = tfidf

        s_list = sorted(tfidf_dict.items(),
                        key=lambda x: x[1],
                        reverse=True)
        top_list = s_list[0:self.kw_num] # 前N个词

        for k, v in top_list:
            print(k + ",", end= "")
        print("")

def tfidf_extract(word_list, keyword_num=20):
    doc_list = load_data('corpus.txt')  # 读取文件内容
    # print(doc_list)
    idf_dic, default_idf = train_idf(doc_list) # 计算逆文档频率

    tfidf_model = TfIdf(idf_dic, default_idf, word_list, keyword_num)
    tfidf_model.get_tfidf()

if __name__ == "__main__":
    global stopword_list

    text = """在中国共产党百年华诞的重要时刻，在“两个一百年”奋斗目标历史交汇关键节点，
    党的十九届六中全会的召开具有重大历史意义。全会审议通过的《决议》全面系统总结了党的百年奋斗
    重大成就和历史经验，特别是着重阐释了党的十八大以来党和国家事业取得的历史性成就、发生的历史性变革，
    充分彰显了中国共产党的历史自觉与历史自信。"""

    stopword_list = get_stopword_list()

    seg_list = jieba.cut(text)  # 分词
    filter_list = word_filter(seg_list)

    # TF-IDF提取关键词
    print('TF-IDF模型结果：')
    tfidf_extract(filter_list)