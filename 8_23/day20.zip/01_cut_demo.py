# 01_cut_demo.py
# 利用jieba库实现中文分词

import jieba

text = "吉林市长春药店"

seg_list = jieba.cut(text, # 待分词文本
                     cut_all=False) # 精确模式
# print(type(seg_list))
for word in seg_list:
    print(word, end="/")
print("")

seg_list = jieba.cut(text, # 待分词文本
                     cut_all=True) # 全模式
for word in seg_list:
    print(word, end="/")
print("")

# 搜索引擎模式
seg_list = jieba.cut_for_search(text)
for word in seg_list:
    print(word, end="/")
print("")
